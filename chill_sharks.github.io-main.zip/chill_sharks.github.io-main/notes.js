class Note{
    constructor(title="", text="", x_dim=100){
        this.title=title;
        this.text=text;
        this.x_dim=x_dim;
    }
}

